import { useState, useRef, useEffect } from "react";

const STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600&family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:wght@300;400;500&display=swap');

  :root {
    --bg: #0d0d0d;
    --surface: #161616;
    --surface2: #1e1e1e;
    --border: #2a2a2a;
    --accent: #c8a96e;
    --accent2: #8fbe8f;
    --text: #e8e2d9;
    --muted: #666;
    --user-bubble: #1a2a1a;
    --ai-bubble: #1c1c1c;
  }

  .app {
    display: flex;
    height: 100vh;
    overflow: hidden;
    font-family: 'IBM Plex Sans', sans-serif;
  }

  /* ── SIDEBAR ── */
  .sidebar {
    width: 320px;
    min-width: 320px;
    background: var(--surface);
    border-right: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    padding: 28px 24px;
    gap: 24px;
  }

  .logo { display: flex; align-items: baseline; gap: 8px; }
  .logo-title {
    font-family: 'Playfair Display', serif;
    font-size: 22px;
    color: var(--accent);
    letter-spacing: 0.02em;
  }
  .logo-sub {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 10px;
    color: var(--muted);
    letter-spacing: 0.1em;
    text-transform: uppercase;
  }

  .divider { height: 1px; background: var(--border); }

  /* Drop zone */
  .drop-zone {
    border: 1.5px dashed var(--border);
    border-radius: 10px;
    padding: 32px 16px;
    text-align: center;
    cursor: pointer;
    transition: border-color 0.2s, background 0.2s;
    position: relative;
    overflow: hidden;
  }
  .drop-zone:hover, .drop-zone.drag-over {
    border-color: var(--accent);
    background: rgba(200,169,110,0.04);
  }
  .drop-zone input[type="file"] {
    position: absolute;
    inset: 0;
    opacity: 0;
    cursor: pointer;
    width: 100%;
    height: 100%;
  }
  .drop-icon { font-size: 32px; margin-bottom: 12px; display: block; }
  .drop-label {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 11px;
    color: var(--muted);
    letter-spacing: 0.08em;
    text-transform: uppercase;
    line-height: 1.7;
  }
  .drop-label span { color: var(--accent); }

  /* File card */
  .file-card {
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 14px 16px;
    display: flex;
    align-items: center;
    gap: 12px;
    animation: slideIn 0.25s ease;
  }
  @keyframes slideIn {
    from { opacity: 0; transform: translateY(-8px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .file-icon {
    width: 38px; height: 38px;
    background: rgba(200,169,110,0.12);
    border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-size: 18px; flex-shrink: 0;
  }
  .file-info { flex: 1; overflow: hidden; }
  .file-name {
    font-size: 12px; font-weight: 500; color: var(--text);
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }
  .file-size {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 10px; color: var(--muted); margin-top: 2px;
  }
  .remove-btn {
    background: none; border: none; color: var(--muted);
    cursor: pointer; font-size: 18px; padding: 4px;
    border-radius: 4px; line-height: 1; transition: color 0.15s;
  }
  .remove-btn:hover { color: #e08080; }

  .status-badge {
    display: inline-flex; align-items: center; gap: 6px;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 10px; letter-spacing: 0.08em;
    padding: 5px 12px; border-radius: 20px; text-transform: uppercase;
  }
  .status-badge.ready {
    background: rgba(143,190,143,0.1);
    color: var(--accent2);
    border: 1px solid rgba(143,190,143,0.2);
  }
  .status-badge .dot {
    width: 6px; height: 6px;
    border-radius: 50%; background: currentColor;
    animation: pulse 2s infinite;
  }
  @keyframes pulse {
    0%, 100% { opacity: 1; } 50% { opacity: 0.3; }
  }

  .how-to {
    font-size: 12px; color: #555; line-height: 1.8;
  }
  .how-to-label {
    color: #888; margin-bottom: 8px;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 10px; letter-spacing: 0.08em; text-transform: uppercase;
  }

  .sidebar-footer {
    margin-top: auto;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 10px; color: var(--muted);
    letter-spacing: 0.05em; line-height: 1.8;
    border-top: 1px solid var(--border); padding-top: 16px;
  }

  /* ── MAIN ── */
  .main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }

  .chat-header {
    padding: 20px 32px;
    border-bottom: 1px solid var(--border);
    display: flex; align-items: center; justify-content: space-between;
    background: var(--surface);
  }
  .chat-title {
    font-family: 'Playfair Display', serif;
    font-size: 17px; color: var(--text); font-weight: 400;
  }
  .chat-subtitle {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 10px; color: var(--muted); margin-top: 3px; letter-spacing: 0.06em;
  }
  .clear-btn {
    background: none;
    border: 1px solid var(--border);
    color: var(--muted);
    padding: 6px 14px; border-radius: 6px;
    cursor: pointer; font-size: 10px;
    font-family: 'IBM Plex Mono', monospace;
    letter-spacing: 0.08em; text-transform: uppercase;
    transition: border-color 0.2s, color 0.2s;
  }
  .clear-btn:hover { border-color: var(--accent); color: var(--accent); }

  /* Messages */
  .messages-area {
    flex: 1; overflow-y: auto;
    padding: 32px; display: flex;
    flex-direction: column; gap: 24px;
    scroll-behavior: smooth;
  }
  .messages-area::-webkit-scrollbar { width: 4px; }
  .messages-area::-webkit-scrollbar-track { background: transparent; }
  .messages-area::-webkit-scrollbar-thumb { background: var(--border); border-radius: 4px; }

  /* Empty state */
  .empty-state {
    flex: 1; display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    gap: 16px; color: var(--muted); text-align: center; padding: 40px;
    margin: auto;
  }
  .empty-icon { font-size: 52px; opacity: 0.25; }
  .empty-title { font-family: 'Playfair Display', serif; font-size: 24px; color: #444; }
  .empty-desc { font-size: 13px; color: var(--muted); max-width: 340px; line-height: 1.8; }

  .suggestion-chips {
    display: flex; flex-wrap: wrap; gap: 8px;
    justify-content: center; margin-top: 8px;
  }
  .chip {
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: 20px; padding: 7px 16px;
    font-size: 12px; color: #888;
    cursor: pointer; transition: border-color 0.2s, color 0.2s;
    font-family: 'IBM Plex Sans', sans-serif;
  }
  .chip:hover { border-color: var(--accent); color: var(--accent); }

  /* Message */
  .message {
    display: flex; gap: 14px;
    animation: msgIn 0.2s ease;
  }
  @keyframes msgIn {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .message.user { flex-direction: row-reverse; align-self: flex-end; max-width: 75%; }
  .message.ai { align-self: flex-start; max-width: 85%; }

  .avatar {
    width: 32px; height: 32px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 10px; flex-shrink: 0;
    font-family: 'IBM Plex Mono', monospace; font-weight: 500;
  }
  .message.user .avatar {
    background: rgba(200,169,110,0.15);
    color: var(--accent);
    border: 1px solid rgba(200,169,110,0.3);
  }
  .message.ai .avatar {
    background: var(--surface2);
    color: var(--accent2);
    border: 1px solid var(--border);
  }

  .bubble {
    padding: 14px 18px; border-radius: 12px;
    font-size: 14px; line-height: 1.8;
  }
  .message.user .bubble {
    background: var(--user-bubble);
    border: 1px solid rgba(143,190,143,0.15);
    color: #d4e8d4;
    border-radius: 12px 4px 12px 12px;
  }
  .message.ai .bubble {
    background: var(--ai-bubble);
    border: 1px solid var(--border);
    color: var(--text);
    border-radius: 4px 12px 12px 12px;
  }

  .bubble p { margin-bottom: 10px; }
  .bubble p:last-child { margin-bottom: 0; }
  .bubble strong { color: var(--accent); font-weight: 500; }
  .bubble h3 {
    font-family: 'Playfair Display', serif;
    font-size: 15px; color: var(--accent);
    margin-bottom: 8px; margin-top: 4px; font-weight: 600;
  }
  .bubble ul, .bubble ol { padding-left: 20px; margin-bottom: 10px; }
  .bubble li { margin-bottom: 5px; }
  .bubble code {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 12px;
    background: rgba(255,255,255,0.06);
    padding: 2px 6px; border-radius: 4px;
    color: var(--accent2);
  }

  /* Typing */
  .typing { display: flex; gap: 4px; padding: 4px 2px; align-items: center; }
  .typing span {
    width: 6px; height: 6px; background: var(--muted);
    border-radius: 50%; animation: bounce 1.2s infinite;
  }
  .typing span:nth-child(2) { animation-delay: 0.2s; }
  .typing span:nth-child(3) { animation-delay: 0.4s; }
  @keyframes bounce {
    0%, 100% { transform: translateY(0); opacity: 0.4; }
    50% { transform: translateY(-5px); opacity: 1; }
  }

  /* Streaming cursor */
  .stream-cursor::after {
    content: '▋';
    animation: blink 0.8s infinite;
    color: var(--accent); margin-left: 2px;
  }
  @keyframes blink {
    0%, 100% { opacity: 1; } 50% { opacity: 0; }
  }

  /* Error bubble */
  .error-bubble {
    background: rgba(200, 60, 60, 0.08);
    border: 1px solid rgba(200, 60, 60, 0.2);
    color: #e08080;
    padding: 12px 16px; border-radius: 8px;
    font-size: 13px;
  }

  /* Input */
  .input-area {
    padding: 20px 32px 24px;
    border-top: 1px solid var(--border);
    background: var(--surface);
  }
  .input-wrapper {
    display: flex; gap: 10px; align-items: flex-end;
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: 12px; padding: 12px 14px;
    transition: border-color 0.2s;
  }
  .input-wrapper:focus-within { border-color: rgba(200,169,110,0.4); }
  .input-wrapper textarea {
    flex: 1; background: none; border: none; outline: none;
    color: var(--text);
    font-family: 'IBM Plex Sans', sans-serif;
    font-size: 14px; line-height: 1.6;
    resize: none; min-height: 22px; max-height: 140px;
    overflow-y: auto; scrollbar-width: none;
  }
  .input-wrapper textarea::placeholder { color: var(--muted); }
  .send-btn {
    width: 36px; height: 36px; border-radius: 8px;
    border: none; background: var(--accent); color: #0d0d0d;
    cursor: pointer; display: flex; align-items: center; justify-content: center;
    font-size: 18px; flex-shrink: 0;
    transition: opacity 0.2s, transform 0.1s; font-weight: bold;
    line-height: 1;
  }
  .send-btn:hover:not(:disabled) { opacity: 0.85; transform: scale(1.05); }
  .send-btn:disabled { opacity: 0.3; cursor: not-allowed; }

  .input-hint {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 10px; color: var(--muted);
    margin-top: 8px; letter-spacing: 0.05em;
  }
  .no-doc-msg {
    font-size: 11px; color: #c8693a;
    font-family: 'IBM Plex Mono', monospace;
    margin-top: 8px; letter-spacing: 0.04em;
  }

  /* Responsive */
  @media (max-width: 640px) {
    .sidebar { width: 100%; min-width: unset; display: none; }
    .app { flex-direction: column; }
  }
`;

function formatText(text) {
  const lines = text.split("\n");
  const elements = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) { i++; continue; }

    if (line.startsWith("### ")) {
      elements.push(<h3 key={i}>{line.slice(4)}</h3>);
    } else if (line.startsWith("## ")) {
      elements.push(<h3 key={i}>{line.slice(3)}</h3>);
    } else if (line.startsWith("- ") || line.startsWith("• ") || line.startsWith("* ")) {
      const items = [];
      while (i < lines.length && (lines[i].startsWith("- ") || lines[i].startsWith("• ") || lines[i].startsWith("* "))) {
        const itemText = lines[i].slice(2);
        items.push(<li key={i}>{renderInline(itemText)}</li>);
        i++;
      }
      elements.push(<ul key={`ul-${i}`}>{items}</ul>);
      continue;
    } else if (/^\d+\.\s/.test(line)) {
      const items = [];
      while (i < lines.length && /^\d+\.\s/.test(lines[i])) {
        const itemText = lines[i].replace(/^\d+\.\s/, "");
        items.push(<li key={i}>{renderInline(itemText)}</li>);
        i++;
      }
      elements.push(<ol key={`ol-${i}`}>{items}</ol>);
      continue;
    } else {
      elements.push(<p key={i}>{renderInline(line)}</p>);
    }
    i++;
  }
  return elements;
}

function renderInline(text) {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**"))
      return <strong key={i}>{part.slice(2, -2)}</strong>;
    if (part.startsWith("`") && part.endsWith("`"))
      return <code key={i}>{part.slice(1, -1)}</code>;
    return part;
  });
}

export default function App() {
  const [file, setFile] = useState(null);
  const [fileData, setFileData] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [streaming, setStreaming] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streaming]);

  const handleFile = (f) => {
    if (!f || f.type !== "application/pdf") return;
    setFile(f);
    setMessages([]);
    setStreaming("");
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target.result.split(",")[1];
      setFileData(base64);
    };
    reader.readAsDataURL(f);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    handleFile(e.dataTransfer.files[0]);
  };

  const sendMessage = async (text) => {
    if (!text.trim() || !fileData || loading) return;

    const userMsg = { role: "user", content: text };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput("");
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
    setLoading(true);
    setStreaming("");

    try {
      // Build API messages — attach PDF only on the first user turn
      const apiMessages = newMessages.map((m, idx) => {
        if (m.role === "user" && idx === 0) {
          return {
            role: "user",
            content: [
              {
                type: "document",
                source: {
                  type: "base64",
                  media_type: "application/pdf",
                  data: fileData,
                },
              },
              { type: "text", text: m.content },
            ],
          };
        }
        return { role: m.role, content: m.content };
      });

      const resp = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1500,
          system:
            "You are an expert document analyst. The user has uploaded a PDF document. Answer all questions strictly based on the content of that document. Be thorough and accurate. Use **bold** for key terms and clause references, ### for section headers when needed, and bullet points for lists. Always cite clause numbers or section names from the document when relevant.",
          messages: apiMessages,
        }),
      });

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({}));
        throw new Error(err.error?.message || `API error ${resp.status}`);
      }

      const data = await resp.json();
      const aiText =
        data.content?.[0]?.text || "Sorry, I could not generate a response.";

      // Simulate streaming effect
      let idx = 0;
      const interval = setInterval(() => {
        idx += 4;
        if (idx >= aiText.length) {
          setStreaming("");
          setMessages((prev) => [
            ...prev,
            { role: "assistant", content: aiText },
          ]);
          setLoading(false);
          clearInterval(interval);
        } else {
          setStreaming(aiText.slice(0, idx));
        }
      }, 10);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: `__error__${err.message}` },
      ]);
      setLoading(false);
      setStreaming("");
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  const autoResize = (e) => {
    const ta = e.target;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 140) + "px";
  };

  const suggestions = [
    "Summarize this document",
    "What are the key test methods?",
    "What specimen sizes are required?",
    "Explain the curing procedure",
    "What is the load rate for compression testing?",
    "List all clause numbers",
  ];

  return (
    <>
      <style>{STYLES}</style>
      <div className="app">
        {/* ── SIDEBAR ── */}
        <div className="sidebar">
          <div className="logo">
            <span className="logo-title">DocMind</span>
            <span className="logo-sub">/ AI Reader</span>
          </div>

          <div className="divider" />

          {!file ? (
            <div
              className={`drop-zone ${dragOver ? "drag-over" : ""}`}
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
            >
              <input
                type="file"
                accept=".pdf"
                onChange={(e) => handleFile(e.target.files[0])}
              />
              <span className="drop-icon">📄</span>
              <div className="drop-label">
                Drop your <span>PDF</span> here
                <br />
                or click to browse
              </div>
            </div>
          ) : (
            <>
              <div className="file-card">
                <div className="file-icon">📑</div>
                <div className="file-info">
                  <div className="file-name">{file.name}</div>
                  <div className="file-size">
                    {(file.size / 1024).toFixed(1)} KB
                  </div>
                </div>
                <button
                  className="remove-btn"
                  onClick={() => {
                    setFile(null);
                    setFileData(null);
                    setMessages([]);
                    setStreaming("");
                  }}
                  title="Remove file"
                >
                  ×
                </button>
              </div>
              <div className="status-badge ready">
                <span className="dot" />
                Document ready
              </div>
            </>
          )}

          <div className="divider" />

          <div className="how-to">
            <div className="how-to-label">How to use</div>
            Upload any PDF document, then ask questions about its content. The
            AI reads the full document and answers based only on what's inside
            it.
          </div>

          <div className="sidebar-footer">
            Powered by Claude AI
            <br />
            Supports PDF documents up to ~30MB
          </div>
        </div>

        {/* ── MAIN ── */}
        <div className="main">
          <div className="chat-header">
            <div>
              <div className="chat-title">Document Analysis Chat</div>
              <div className="chat-subtitle">
                {file ? `Analyzing: ${file.name}` : "No document loaded — upload a PDF to begin"}
              </div>
            </div>
            {messages.length > 0 && (
              <button
                className="clear-btn"
                onClick={() => { setMessages([]); setStreaming(""); }}
              >
                Clear chat
              </button>
            )}
          </div>

          <div className="messages-area">
            {messages.length === 0 && !loading ? (
              <div className="empty-state">
                <span className="empty-icon">🔍</span>
                <div className="empty-title">Ask about your document</div>
                <div className="empty-desc">
                  {file
                    ? "Your document is loaded. Ask anything about its contents — the AI will answer using only information from the PDF."
                    : "Upload a PDF document on the left panel to get started."}
                </div>
                {file && (
                  <div className="suggestion-chips">
                    {suggestions.map((s) => (
                      <button
                        key={s}
                        className="chip"
                        onClick={() => sendMessage(s)}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <>
                {messages.map((msg, i) => (
                  <div
                    key={i}
                    className={`message ${msg.role === "user" ? "user" : "ai"}`}
                  >
                    <div className="avatar">
                      {msg.role === "user" ? "YOU" : "AI"}
                    </div>
                    <div className="bubble">
                      {msg.role === "assistant" ? (
                        msg.content.startsWith("__error__") ? (
                          <div className="error-bubble">
                            ⚠ {msg.content.slice(9)}
                          </div>
                        ) : (
                          formatText(msg.content)
                        )
                      ) : (
                        msg.content
                      )}
                    </div>
                  </div>
                ))}

                {streaming && (
                  <div className="message ai">
                    <div className="avatar">AI</div>
                    <div className="bubble stream-cursor">
                      {formatText(streaming)}
                    </div>
                  </div>
                )}

                {loading && !streaming && (
                  <div className="message ai">
                    <div className="avatar">AI</div>
                    <div className="bubble">
                      <div className="typing">
                        <span />
                        <span />
                        <span />
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="input-area">
            <div className="input-wrapper">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => {
                  setInput(e.target.value);
                  autoResize(e);
                }}
                onKeyDown={handleKeyDown}
                placeholder={
                  file
                    ? "Ask anything about your document..."
                    : "Upload a PDF to start asking questions..."
                }
                disabled={!file || loading}
                rows={1}
              />
              <button
                className="send-btn"
                onClick={() => sendMessage(input)}
                disabled={!input.trim() || !file || loading}
              >
                ↑
              </button>
            </div>
            {!file && (
              <div className="no-doc-msg">
                ⚠ Upload a PDF document to enable chat
              </div>
            )}
            {file && (
              <div className="input-hint">
                ENTER to send · SHIFT+ENTER for new line
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
